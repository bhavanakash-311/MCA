#include <iostream>
using namespace std;

int main() {
    int N;
    cout << "Enter the value of N: ";
    cin >> N;

    for (int num = 2; num <= N; num++) {

        bool prime = true;

        for (int d = 2; d * d <= num; d++) {
            if (num % d == 0) {
                prime = false;
                break;
            }
        }

        if (!prime)
            continue;

        int digits = 0;
        int temp = num;

        while (temp > 0) {
            digits++;
            temp /= 10;
        }

        int power = 1;

        for (int i = 1; i < digits; i++)
            power *= 10;

        int current = num;
        bool circular = true;

        for (int i = 0; i < digits; i++) {

            int last = current % 10;
            current = current / 10 + last * power;

            bool rotationPrime = true;

            for (int d = 2; d * d <= current; d++) {
                if (current % d == 0) {
                    rotationPrime = false;
                    break;
                }
            }

            if (!rotationPrime) {
                circular = false;
                break;
            }
        }

        if (circular)
            cout << num << " ";
    }

    cout << endl;

    return 0;
}