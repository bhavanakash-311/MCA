#include <iostream>
using namespace std;

int main(){

    int l;
    int r;
    cin>>l;
    cin>>r;
    int count =0;
    int sum=0,largesti = 0,largestj=0;
    

    for(int i=l;i<=r;i++){
        int isprime = 1;
        if(i == 1){
            isprime = 0;
        }
        int num = i;
        for(int k=2;k<num;k++){
            if(num%k==0){
                isprime = 0;
                break;
            }
        }
        if(isprime == 1){
            for(int j=i+1;j<=r;j++){
                int isprime = 1;
                int num = j;
                for(int k=2;k<num;k++){
                    if(num%k==0){
                        isprime = 0;
                        break;
                    }
                }
                if(isprime ==1){

                    if(j-i == 2){
                        sum += i+j;
                        cout <<"(" <<i<<","<<j<<")"<<endl;
                        count++;
                        largesti = i;
                        largestj = j;
                    }
                }
            }
        }
    }
    cout << "Total number of twin prime pairs: "<< count <<endl;
    cout << "Sum of all prime in twin prime pairs: "<< sum<<endl;
    cout << "Largest twin prime: " <<"(" <<largesti<<","<<largestj<<")"<<endl;
    
    return 0;

}