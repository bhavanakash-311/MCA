#include <iostream>
using namespace std;

int main() {
    int L, R;
    cin >> L >> R;

    int prevPrime = 0;
    int maxGap = -1;
    int p1 = 0, p2 = 0;

    int num = 2;

    while(num <= R){
        bool prime = true;
        int divisor = 2;

        while (divisor * divisor <= num){
            if (num % divisor == 0) {
                prime = false;
                break;
            }
            divisor++;
        }

        if (prime){
            if (num >= L && prevPrime != 0){
                int gap = num - prevPrime;

                if (gap > maxGap) {
                    maxGap = gap;
                    p1 = prevPrime;
                    p2 = num;
                }
            }

            prevPrime = num;
        }

        num++;
    }

    if (maxGap == -1){
        cout << "No consecutive prime pairs found in the given range.";
    } else{
        cout << "The largest prime gap is between "
             << p1 << " and " << p2
             << " with a gap of " << maxGap << endl;
    }

    return 0;
}