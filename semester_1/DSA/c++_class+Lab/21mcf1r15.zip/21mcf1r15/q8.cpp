#include <iostream>
using namespace std;

int main(){
        int num,digitcountnum=0 ;
        int number;

        cin>> num;
        number = num;
        while (number>0){
            number = number/10;
            digitcountnum++;
        }

        int square = num*num;   
        int num1 =0;
        int num2 =0;
    
        
    
        int divide = digitcountnum  ;
        int division =1;
        while(divide>0){
            division *=10;
            divide--;
        }
        num1 = square % division;
        
        num2 = square/division;
        
    
        int sum = num1+num2;
        if(num == sum){
            cout << num <<" is a karpekar number";
        }else{
            cout <<num<< " is not a karpekar number";
        }
        
    return 0;
}