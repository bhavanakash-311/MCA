#include <iostream>
using namespace std;

int main(){
    int num;
    // cout <<"Enter your number: ";
    cin>>num;
    int k = num;
    int sum =0;

    while(sum!= 1 && sum!= 4){
        sum = 0;
        while(num>0){
            int lastdigit = num%10;
            sum += lastdigit*lastdigit;
            num = num/10;

        }
        num = sum;
        
    }

    if(num == 1){
        cout<<k<<" is the happy number.";
    }else {
        cout <<k<<" is not happy number.";
    }
    return 0;
}