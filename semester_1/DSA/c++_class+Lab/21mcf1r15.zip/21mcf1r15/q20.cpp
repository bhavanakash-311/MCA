#include <iostream>
using namespace std;

int main() {
    long long A, B;

    cout << "Enter A: ";
    cin >> A;

    cout << "Enter B: ";
    cin >> B;

    long long maxScore = -1;
    long long winner = -1;
    bool found = false;

    cout << "\nWinning numbers between " << A << " and " << B << ":" << endl;

    for (long long i = A; i <= B; i++) {

        long long temp = i;
        long long sum = 0;
        long long product = 1;
        long long reverse = 0;
        int digits = 0;

        while (temp > 0) {
            long long digit = temp % 10;

            sum += digit;
            product *= digit;
            reverse = reverse * 10 + digit;

            digits++;
            temp /= 10;
        }

        int divisors = 0;

        for (long long d = 1; d * d <= i; d++) {
            if (i % d == 0) {
                divisors++;

                if (d * d != i)
                    divisors++;
            }
        }

        bool prime = true;

        if (reverse <= 1) {
            prime = false;
        } else {
            for (long long d = 2; d * d <= reverse; d++) {
                if (reverse % d == 0) {
                    prime = false;
                    break;
                }
            }
        }

        if (product > sum && divisors > digits && prime) {

            found = true;

            long long score = product * divisors;

            cout << "Number: " << i
                 << " | Digit Sum: " << sum
                 << " | Digit Product: " << product
                 << " | Num Digits: " << digits
                 << " | Num Divisors: " << divisors
                 << " | Reverse: " << reverse
                 << " | Score: " << score << endl;

            if (score > maxScore) {
                maxScore = score;
                winner = i;
            } else if (score == maxScore && i < winner) {
                winner = i;
            }
        }
    }

    if (found) {
        cout << "\nOverall Winner: " << winner
             << " with a score of " << maxScore << endl;
    } else {
        cout << "\nNo winning numbers found in the given range." << endl;
    }

    return 0;
}