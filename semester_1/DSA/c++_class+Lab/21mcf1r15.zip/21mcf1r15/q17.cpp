#include <iostream>
using namespace std;

int main() {
    int N;
    cout << "Enter the value of N: ";
    cin >> N;

    int total = 0;
    long long sum = 0;
    int largest = -1;
    int smallest = -1;

    int maxCount = -1;
    int bestRow = 1;

    for (int i = 1; i <= N; i++) {

        int rowCount = 0;

        for (int j = 1; j <= N; j++) {

            int val = i * j;

            bool prime = true;

            if (val <= 1) {
                prime = false;
            } else {
                for (int d = 2; d * d <= val; d++) {
                    if (val % d == 0) {
                        prime = false;
                        break;
                    }
                }
            }

            bool palindrome = true;
            int temp = val;
            int rev = 0;

            while (temp > 0) {
                rev = rev * 10 + temp % 10;
                temp /= 10;
            }

            if (rev != val)
                palindrome = false;

            int digits = 0;
            temp = val;

            if (temp == 0) {
                digits = 1;
            } else {
                while (temp > 0) {
                    digits++;
                    temp /= 10;
                }
            }

            int armstrongSum = 0;
            temp = val;

            while (temp > 0) {
                int digit = temp % 10;
                int power = 1;

                for (int k = 1; k <= digits; k++)
                    power *= digit;

                armstrongSum += power;
                temp /= 10;
            }

            bool armstrong = (armstrongSum == val);

            bool perfect = false;

            if (val > 1) {
                int divisorSum = 1;

                for (int d = 2; d * d <= val; d++) {
                    if (val % d == 0) {
                        divisorSum += d;

                        if (d * d != val)
                            divisorSum += val / d;
                    }
                }

                if (divisorSum == val)
                    perfect = true;
            }

            int count = 0;

            if (prime)
                count++;

            if (palindrome)
                count++;

            if (armstrong)
                count++;

            if (perfect)
                count++;

            if (count == 2) {
                cout << "M(" << i << ", " << j << ") = "
                     << val << " satisfies exactly 2 properties." << endl;

                total++;
                sum += val;
                rowCount++;

                if (largest == -1 || val > largest)
                    largest = val;

                if (smallest == -1 || val < smallest)
                    smallest = val;
            }
        }

        if (rowCount > maxCount) {
            maxCount = rowCount;
            bestRow = i;
        }
    }

    cout << "\n--- Results ---" << endl;

    cout << "(a) Total number of such values: " << total << endl;

    cout << "(b) Largest such value: "
         << (largest == -1 ? 0 : largest) << endl;

    cout << "(c) Smallest such value: "
         << (smallest == -1 ? 0 : smallest) << endl;

    cout << "(d) Sum of all such values: "
         << sum << endl;

    cout << "(e) Row containing the maximum number of such values: Row "
         << bestRow << " (Count: " << maxCount << ")" << endl;

    return 0;
}