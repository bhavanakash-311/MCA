#include <iostream>
using namespace std;

int main() {
    long long A, B;

    cout << "Enter A: ";
    cin >> A;

    cout << "Enter B: ";
    cin >> B;

    bool anagram = true;

    for (int d = 0; d <= 9; d++) {
        int countA = 0;
        int countB = 0;

        long long tempA = A;
        long long tempB = B;

        if (tempA == 0 && d == 0)
            countA = 1;

        while (tempA > 0) {
            if (tempA % 10 == d)
                countA++;
            tempA /= 10;
        }

        if (tempB == 0 && d == 0)
            countB = 1;

        while (tempB > 0) {
            if (tempB % 10 == d)
                countB++;
            tempB /= 10;
        }

        if (countA != countB) {
            anagram = false;
            break;
        }
    }

    if (anagram)
        cout << "Anagrams of digits";
    else
        cout << "Not anagrams";

    return 0;
}