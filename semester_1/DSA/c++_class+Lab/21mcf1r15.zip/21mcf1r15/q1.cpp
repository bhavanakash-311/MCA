#include <iostream>
using namespace std;

int main(){
    int n;
    cout<< "enter your numbe:";
    cin>>n;
    int num = 2;
    for(int i=1;i<=n;i++){        
        int k=0;
        while(k<i){
                int isnotprime = 0;
                for(int j=2;j<num;j++){
                    if(num%j==0){
                        isnotprime=1;
                        break;
                    }
                }
                if(isnotprime==0){
                    cout << num <<" ";
                    k++;
                }
                num++;
            }
        
        cout<< endl;
    }
}