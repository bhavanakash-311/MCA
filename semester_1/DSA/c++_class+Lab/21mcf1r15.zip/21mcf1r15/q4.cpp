#include <iostream>

using namespace std;

int main() {
    int N;
    cout << "Enter the value of N: ";
    cin >> N;

    int num = 2;
    int rows = 2 * N - 1;

    for (int i = 1; i <= rows; i++){
        int spaces, count;

        if(i <= N){
            spaces = N - i;
            count = 2 * i - 1;
        }else{
            spaces = i - N;
            count = 2 * (rows - i + 1) - 1;
        }

        for(int j = 0; j < spaces; j++){
            cout << "   ";
        }

        int printed = 0;

        while(printed < count){
            bool prime = true;
            for (int j = 2; j < num; j++) {
                if (num % j == 0) {
                    prime = false;
                    break;
                }
            }

            if(prime){
                if(num < 10){
                    cout << num << "  ";
                }else{
                    cout << num << " ";
                }
                printed++;
            }

            num++;
        }

        cout << endl;
    }

    return 0;
}