#include <iostream>
using namespace std;

int main(){
    int n;
    cin>>n;
    int sum=0;
    int sum2=0;
    int llargest =0;
    int smallest =0;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            if(i==j){
                sum += i*j;
            }
            if(j==n-i+1){
                sum2 += i*j;
            }
            if(i==n-1 && j==n){
                llargest = i*j;
            }
            if(i==2 && j==1){
             smallest = i*j;
            }
             cout << i*j << " ";
        }
        cout << endl;
    }
    cout << "Main diagonal Sum is:" <<sum <<endl;
    cout << "Secondary diagonal sum is: " <<sum2 <<endl;
    cout << "Largest element above main diagonal: "<<llargest <<endl;
    cout << "Smallest element below main diagonal: "<<smallest <<endl;
    return 0;
}