#include <iostream>
using namespace std;

int main() {
    int N;
    cout << "Enter the value of N: ";
    cin >> N;

    cout << "Original numbers for which the resulting number satisfies exactly two properties:" << endl;

    for (int i = 1; i <= N; i++) {

        int temp = i;
        int rev = 0;

        while (temp > 0) {
            rev = rev * 10 + temp % 10;
            temp /= 10;
        }

        long long result = i + rev;

        bool prime = true;

        if (result <= 1) {
            prime = false;
        } else {
            for (long long d = 2; d * d <= result; d++) {
                if (result % d == 0) {
                    prime = false;
                    break;
                }
            }
        }

        temp = result;
        long long reverseResult = 0;

        while (temp > 0) {
            reverseResult = reverseResult * 10 + temp % 10;
            temp /= 10;
        }

        bool palindrome = (reverseResult == result);

        bool perfect = false;

        if (result > 1) {
            long long sum = 1;

            for (long long d = 2; d * d <= result; d++) {
                if (result % d == 0) {
                    sum += d;

                    if (d * d != result)
                        sum += result / d;
                }
            }

            if (sum == result)
                perfect = true;
        }

        int count = 0;

        if (prime)
            count++;

        if (palindrome)
            count++;

        if (perfect)
            count++;

        if (count == 2) {
            cout << i << " (Resulting sum: " << result << ")" << endl;
        }
    }

    return 0;
}