#include <iostream>
using namespace std;

int main(){
    int n;
    
    cin >> n;
    int largestps=0,numps=0;
    
    for(int i=1;i<=n;i++){
        int powerscore = 0;
        int num = i;
        int count = 0;
        int sum = 0;
        for(int j=1;j<=i;j++){
            if(num%j==0){
                count ++;
                sum += j;
                
            }
        }
        cout <<"for "<<i<< " Number of divisors are: "<<count<<endl;
        cout <<"for "<<i<< " sum of divisors are: "<< sum <<endl;
        int digitsum = 0;
        int k =i;
        while(k>0){
            int lastdigit = k%10;
            k = k/10;
            digitsum += lastdigit;

        }
        cout <<"for "<<i<< " digitsum is : "<< digitsum<<endl;
        powerscore = count*digitsum;
        if(powerscore > largestps){
            largestps = powerscore;
            numps = i;
        }

        cout<<endl;

    }
    cout<< numps <<" has the lagestest powersum = " <<largestps;
    return 0;
}