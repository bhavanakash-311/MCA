#include <iostream>
using namespace std;

int main(){
    int n;
    cin>>n;

    for(int i=1;i<=n*2 -1;i++){
        if(i<=n){
            for(int j=n-i;j>=1;j--){
                cout<< "  ";
            }
    
            for(int k=1;k<=i;k++){
                cout << k<<" ";
            }
            for(int l=1;l<=i-1;l++){
                cout<<l<<" ";
            }
            cout<< endl;
        }
        else{
            for(int j=1;j<=i-n;j++){
                cout<< "  ";
            }
            for(int k=1;k<=2*n-i;k++){
                cout<< k<< " ";

            }
            for(int l=1;l<=2*n-i-1;l++){
                cout<< l<<" ";

            }
            cout<<endl;
        }
    }
    return 0;
}