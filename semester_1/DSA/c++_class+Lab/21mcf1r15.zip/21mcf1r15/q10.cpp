#include <iostream>
using namespace std;

int main(){
    int num;
    cin >> num;

    int original = num;
    int  isdes= 1;

    for (int digit = 0; digit <= 9; digit++){
        int temp = original;
        int count = 0;

        while (temp > 0){
            int current = temp % 10;
            if (current == digit){
                count++;
            }

            temp = temp / 10;
        }
        int division = 1;
        int i = 0;

        while (i < digit){
            division = division * 10;
            i++;
        }

        int rdigit = (original / division) % 10;
        if (count != rdigit)
        {
            isdes = 0;
        }
    }

    if (isdes == 1){
        cout << num << " is a self-descriptive number";
    }
    else{
        cout << num << " is not a self-descriptive number";
    }

    return 0;
}