#include <iostream>
using namespace std;

int main(){
    int n;
    cin>>n;
    int max =0;
    int element = 0;

    for(int i=1;i<=n;i++){
        int prop = 0;
        int isprime = 1;
        int ispalindrome = 0;
        int isarmstrong = 0;
        int isperfect = 0;
        int isstrong = 0;
        int isautomorphic = 0;
        int ishappy = 0;

        //prime
        if(i == 1){
            isprime = 0;
        }
        int num = i;
        for(int k=2;k<num;k++){
            if(num%k==0){
                isprime = 0;
                //cout << "prime";
                break;
            }
        }
        if(isprime == 1){
            prop++;

        }

        //palindrome
        int reverseNum =0;
        while(num > 0){
            int digit = num%10;
            reverseNum = (reverseNum*10) + digit;
            num = num/10;
        }
        if(reverseNum == i){
            ispalindrome =1;
            prop ++;
            //cout<<"palindrome";
        }

        //armstrong
        num = i;
        int arms = 0;
        while(num>0){
            int lastdigit = num%10;
            arms =  lastdigit*lastdigit*lastdigit + arms;
            num = num/10;

        }
        if(arms == i){
            isarmstrong = 1;
            prop++;
            //cout << "Armstrong";
        }

        //perfect
        num = i;
        int sum = 0;
        for(int j=1;j<i;j++){
            if(num%j==0){
            sum += j;
                
            }
        }
        if(sum == i){
            isperfect = 1;
            prop++;
            //cout << "perfect";
        }
        //strong
        num = i;
        sum = 0;
        while(num>0){
            int lastdigit = num%10;
            int factorial = 1;
            while(lastdigit>0){
                factorial *= lastdigit;
                lastdigit--;
            }
            sum += factorial;
            num = num/10;

        }
        if(i == sum){
            isstrong =1;
            prop++;
            //cout <<"strong";
        }

        //Automorphic
        num = i;
        int square = num * num;

        int digitcount = 0;
        int m = num;
        while (m > 0){
            m = m / 10;
            digitcount++;
        }
        int divide = digitcount ;
        int division = 1;
        while(divide>0){
            division *=10;
            divide--;
        }

        int res = square % division;
        if(i == res){
            isautomorphic = 1;
            //cout<<"automorphic";
            prop++;
        }

        //ishappy

        num = i;
        sum = 0;
        while(num!= 1 && num!= 4){
            sum = 0;
            while(num>0){
                int lastdigit = num%10;
                sum += lastdigit*lastdigit;
                num = num/10;

            }
        num = sum;
        
        if(num == 1){
            prop++;
            ishappy = 1;
            
        }

    }

    cout << i <<" "<< prop <<endl;
    //three properties 
    if(prop>=3){
        //cout << "Number satisfying atleast three properties: "<<i<<endl;
    }
    
    if(prop>max){
        max = prop ;
        element = i;
    }

    
         
    }
    //cout << "Number satisfying maximum properties: "<< element;
    return 0;

}