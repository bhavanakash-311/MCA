#include <iostream>
using namespace std;

int main() {
    long long N;
    cout << "Enter the value of N: ";
    cin >> N;

    if (N <= 0) {
        cout << "Please enter a positive integer.";
        return 0;
    }

    long long temp = N;
    int digits = 0;
    long long divisor = 1;

    while (temp > 0) {
        digits++;
        temp /= 10;

        if (temp > 0)
            divisor *= 10;
    }

    if (digits == 1) {
        cout << "Longest Strictly Increasing Sequence: Length = 1, Digits = " << N << endl;
        cout << "Longest Strictly Decreasing Sequence: Length = 1, Digits = " << N << endl;
        cout << "Longest Equal Consecutive Sequence: Length = 1, Digits = " << N << endl;
        return 0;
    }

    int maxInc = 1, currInc = 1;
    int maxDec = 1, currDec = 1;
    int maxEqual = 1, currEqual = 1;

    long long incNumber = 0;
    long long decNumber = 0;
    long long equalNumber = 0;

    temp = N;

    long long prev = temp / divisor;
    temp %= divisor;
    divisor /= 10;

    incNumber = prev;
    decNumber = prev;
    equalNumber = prev;

    for (int i = 1; i < digits; i++) {

        long long curr = temp / divisor;
        temp %= divisor;
        divisor /= 10;

        if (curr > prev) {
            currInc++;
            incNumber = incNumber * 10 + curr;
        } else {
            currInc = 1;
            incNumber = curr;
        }

        if (currInc > maxInc) {
            maxInc = currInc;
        }

        if (curr < prev) {
            currDec++;
            decNumber = decNumber * 10 + curr;
        } else {
            currDec = 1;
            decNumber = curr;
        }

        if (currDec > maxDec) {
            maxDec = currDec;
        }

        if (curr == prev) {
            currEqual++;
            equalNumber = equalNumber * 10 + curr;
        } else {
            currEqual = 1;
            equalNumber = curr;
        }

        if (currEqual > maxEqual) {
            maxEqual = currEqual;
        }

        prev = curr;
    }

    cout << "\n--- Results ---" << endl;

    cout << "1. Strictly Increasing Sequence:" << endl;
    cout << "   Length = " << maxInc
         << ", Digits = " << incNumber << endl;

    cout << "2. Strictly Decreasing Sequence:" << endl;
    cout << "   Length = " << maxDec
         << ", Digits = " << decNumber << endl;

    cout << "3. Equal Consecutive Sequence:" << endl;
    cout << "   Length = " << maxEqual
         << ", Digits = " << equalNumber << endl;

    return 0;
}