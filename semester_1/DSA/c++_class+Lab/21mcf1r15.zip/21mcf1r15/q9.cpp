#include <iostream>
using namespace std;

int main(){
    int n;
    cin >> n;

    for (int num = 1; num <= n; num++){
        int square = num * num;

        int digitcount = 0;
        int m = num;

        while (m > 0){
            m = m / 10;
            digitcount++;
        }

        int divide = digitcount;
        int division = 1;

        while (divide > 0){
            division *= 10;
            divide--;
        }

        int res = square % division;

        if (num == res){
            cout << num << " ";
        }
    }

    return 0;
}