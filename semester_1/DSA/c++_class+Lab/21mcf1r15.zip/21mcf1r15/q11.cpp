#include <iostream>
using namespace std;

int main(){

    int n;
    // cout << "Enter your number of collatz sequence: ";
    cin >> n;
    int count,maxi=0,k = 0;
    int lvalue = 0;
    
    for(int i=1;i<=n;i++){
        count = 1;
        int num = i;  
        cout << num << " ";

        while(num!=1){
            if(num%2==0){
                num = num/2;
                cout<<num<< " ";               
                count++;
            }else{
                num = 3*num + 1;
                cout <<num <<" ";
                count++;
            }
        }
        cout <<endl;
        if(count > maxi){
            maxi = count;
            k = i;
        }
    }
    cout << "starting number: "<< k <<endl;
    cout << "Maximum lenght of the sequence: "<<maxi <<endl;

    return 0;

}